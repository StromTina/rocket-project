export function trueOrFalse() {
    return Math.random() < 0.5;
}